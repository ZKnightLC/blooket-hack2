# Blooket-Hack
All of the cheats are based on a game mode.

**Support Discord Server: https://discord.gg/bGRN82QQYM**

So if you choose a gold quest game mode then you go to the gold folder ![image](https://user-images.githubusercontent.com/73669084/133948292-c476474b-b79b-4760-866e-96ede980ad91.png) and then use one of the cheats in that folder.

**If anything isn't working please make a issue after checking with the FAQ: https://github.com/glixzzy/blooket-hack/issues**

# Video Tutorial
https://user-images.githubusercontent.com/73669084/133946393-fdb99491-40b1-470e-b4e2-2c70c0eae866.mp4

# Without the console (bookmarklet) tutorial:
1. Make a bookmark (the star on the right side of the url bar if you are using chrome)
2. Click on more at the bottom left corner
3. Delete everything in the url box
4. Type `javascript:`
5. Paste in the code

# Bookmarklet Video Tutorial:
https://streamable.com/t4u7i7

# Frequently Asked Questions

Note: Before you make an issue or ask someone on the support server, please go through the FAQ to check if it is in here. Thank you.

**Q: How do I run the code?**

A: There are two main ways to run the code on this repository. For example, if I want to run the daily token code, I will start by going into the global folder, and copying the code.

Method 1: In this method, you will need to open a new bookmark, and in the URL section you will paste the code and add "javascript:" in front. So I would type "`javascript: fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/addTokens.js").then((res) => res.text().then((t) => eval(t)))`" into the URL section. You can name the bookmark whatever you please, it has no effect on the code. To run the bookmark, simply click the bookmark on the desired page.

Method 2: In this method, you will need to open inspect element. Paste the desired code into the console, and hit enter to run. <img width="206" alt="Screen Shot 2021-10-07 at 6 24 23 PM" src="https://user-images.githubusercontent.com/92130749/136483638-f0b4e11c-a7f8-46af-ae53-e94e38397c94.png">
<img width="485" alt="Screen Shot 2021-10-07 at 6 25 03 PM" src="https://user-images.githubusercontent.com/92130749/136483687-5a87104c-fc83-4aa3-be7e-dd5d96906ef1.png">

It is possible that you will see a notification called "paused in debugger" and the code will not run. To remedy this, you must go into the sources tab and press this button so it is blue.

<img width="69" alt="Screen Shot 2021-10-07 at 6 26 58 PM" src="https://user-images.githubusercontent.com/92130749/136483809-3d5acc3f-4e12-45dc-87a9-4d18f303f58c.png">

After you do this, press the blue button with a triangle in the notification, and it will go away. Then you can do the steps outlined above and it will run.


**Q: The all permanent blooks isn't working!**

A: Yes, it was a joke and does not permanently work.


**Q: Is there any way to bypass the 500 token per day limit or change the time before reset timer?**

A: Nope! This is simply not possible, because it is server-side.


**Q: Can I make my custom blook skins and use them?**

A: No, this is also currently not possible.

**Q: Ahhh! My account was banned! Was I just banned for hacking blooket?**
![Screen Shot 2021-10-07 at 6 39 06 PM](https://user-images.githubusercontent.com/92130749/136484808-0dada02e-ae99-49cd-b036-d2a13c8c9684.png)

A: Probably not, this is a bug that is going around that doesn't let you in your account for a short period of time. The best thing to do is just wait it out.


